angular.module("app").constant("env", {
  apiUrl: "https://gateway.marvel.com:443/v1/public",
});
