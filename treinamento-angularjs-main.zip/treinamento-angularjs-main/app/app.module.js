angular.module("app", ["ui.router", "ngAnimate"]);
